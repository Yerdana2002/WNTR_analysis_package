# file_handling module
# Functions defined in this module have to do with reading, saving, and changing values in files in csv and INP format


import os
import pandas as pd
import logging

# read_data_csv function takes the following parameters:
# - file path (str) : path to the CSV file
# - calculate_k (default: True) : calculates the average k value in the csv file
# - decimal_points (int default: 3) : rounds average k value to the specified decimal points

# The output of the function: returns pandas 

def read_data_csv(file_path, calculate_k=True, decimal_points=3):
    try:
        data = pd.read_csv(file_path)
        if calculate_k and 'k' in data.columns:
            average_k = -data['k'].mean().round(decimal_points)
            logging.info(f"Using average k value: {average_k}")
            return data, average_k
        return data, None
    except Exception as e:
        logging.error(f"An error occurred while reading the CSV file: {e}")
        return None, None

def save_results(output_base_dir, data, filename="base_line", save_as_csv=True):
    try:
        os.makedirs(output_base_dir, exist_ok=True)
        file_extension = ".csv" if save_as_csv else ".txt"
        output_file_path = os.path.join(output_base_dir, f"{filename}{file_extension}")
        data.to_csv(output_file_path, index=False, sep='\t' if not save_as_csv else ',')
        logging.info(f"Data saved successfully to '{output_file_path}'")
        return True
    except Exception as e:
        logging.error(f"Failed to save data: {e}")
        return False

def modify_decay_coefficients(inp_path, wall_coeff, bulk_coeff):
    try:
        with open(inp_path, 'r') as file:
            lines = file.readlines()

        for i, line in enumerate(lines):
            if bulk_coeff is not None and line.strip().startswith('Global Bulk'):
                lines[i] = f"Global Bulk            {bulk_coeff}\n"
            elif wall_coeff is not None and line.strip().startswith('Global Wall'):
                lines[i] = f"Global Wall            {wall_coeff}\n"

        with open(inp_path, 'w') as file:
            file.writelines(lines)

    except FileNotFoundError:
        logging.error(f"Error: The file at {inp_path} was not found.")
    except Exception as e:
        logging.error(f"An error occurred: {e}")
