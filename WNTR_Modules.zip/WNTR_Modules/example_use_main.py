import main 
import GMM
import flow_pattern
import numpy as np
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture
import pandas as pd
from sklearn.preprocessing import StandardScaler


# Example usage:
# First we need to start by clustering the data in csv format by applying GMM over Average Flow
# To do that, we need to scale the 'Average Flow' values in the csv file

# Load your CSV file
file_path = r"C:\Users\binia\OneDrive\Desktop\BIG\Updated_Daily_Averages.csv"
data = pd.read_csv(file_path)

# Convert 'Date' column to datetime
data['Date'] = pd.to_datetime(data['Date'])

# Standardize the 'Average Flow' before applying GMM
scaler = StandardScaler()
data['Average Flow Scaled'] = scaler.fit_transform(data[['Average Flow']])

num_of_clusters = find_optimal_clusters(data, feature_column = 'Average Flow Scaled')

# Now we are applying GMM
data = pd.read_csv(file_path)
data_with_clusters, gmm = apply_gmm(data, num_of_clusters, feature_column = 'Average Flow Scaled')

# Now we are saving individual CSV files that belong to clusters defined by user and GMM
# We need to create a dictionary with cluster names, in our case we have 4 clusters as defined by find_optimal_clusters output
cluster_mapping_dict = {  ## I need to modify the mapping by asking the user what they want to name 
#each cluster on a terminal based on optimal_cluster_number
    0 : 'Low',
    1 : 'Lower-Medium',
    2 : 'Upper_Medium',
    3 : 'High'
}
## User needs to define this dictionary by themselves
## Also, the ouput file path here is just a placeholder for the real file path.
updated_file_path = r"C:\Users\binia\OneDrive\Desktop\4gmm\data\All_average_flows&Temperature_cluster.csv"
GMM.split_and_save(data_with_clusters, cluster_mapping_dict, updated_file_path, feature_column = 'Average Flow Scaled')

#*************************************************************************************************************************

## Now this is method 2 of achieving the same result but with only 1 line of code

# run_gmm_clustering(file_path, updated_file_path, feature_column='Average Flow Scaled', max_clusters=10)

#*************************************************************************************************************************

complete_data_path = r"C:\Users\binia\OneDrive\Desktop\4gmm\data\complete_data.csv"
cluster_name = 'High'
filtered_data = load_and_filter_data(complete_data_path, cluster_name)

expected_probabilities = {3: 0.14, 5: 0.86}
compare_actual_to_expected_probabilities(filtered_data, expected_probabilities)

# Filtering representative patterns
# There is an issue with the path to the file parameter. 
filtered_patterns = filter_representative_patterns(r"C:\path\to\file.csv", [1, 2, 3])
filtered_patterns.to_csv(r"C:\path\to\save.csv", index=False)

# Merge and save filtered patterns
merge_and_save_filtered_patterns(cluster_paths)

# Update with temperature
update_with_temperature(file_paths)

# Calculate k using Arrhenius
mean_k_converted = calculate_k_using_arrhenius(file_paths, 2.976, 288.85, 3.912, 292.55)

# Visualize flow patterns
plot_flow_patterns(cluster_flow_patterns, r"C:\Users\binia\OneDrive\Desktop\4gmm\data\complete_data.csv")

# Paths to necessary files
inp_file_path = r"C:\Users\binia\OneDrive\Desktop\4gmm\pattern\31 Anytown.inp"
data_file_path = r"C:\Users\binia\OneDrive\Desktop\4gmm\data\high_complete_data.csv"
output_base_dir = r"C:\Users\binia\OneDrive\Desktop\4gmm\simulation\High"

# Running the simulation
run_water_network_simulation(
    inp_file_path=inp_file_path,
    data_file_path=data_file_path,
    output_base_dir=output_base_dir,
    node_of_interest='90',  # Example node, can be any node in the model
    bulk_decay_coefficient=-2,
    wall_decay_coefficient=-0.1,
    pattern_name=None,  # Replace with actual pattern name if needed
    start_time=24,
    end_time=48,
    save_as_csv=True
)



