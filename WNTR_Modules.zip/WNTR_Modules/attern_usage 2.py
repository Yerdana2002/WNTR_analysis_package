import main 
import flow_pattern


file_path = r"C:\\Users\\binia\\OneDrive\\Desktop\\4gmm\\data\\All_Flow_Pattern_Dateweek.csv"

data = pd.read_csv(file_path)

scaled_data_with_columns, scaled_data_wihtout_columns, scaler = flow_pattern.preprocess_data(file_path, drop_columns=['Date', 'Day_of_week'])

pca_applied_df, pca_model = flow_pattern.apply_pca(scaled_data_without_columns, variance_threshold = 0.80)

best_k = flow_pattern.determine_optimal_clusters(pca_applied_df, max_clusters=10)

flow_pattern.plot_silhouette(pca_applied_df, best_k)

cluster_centroids, cluster_labels = flow_pattern.kmeans_clustering(pca_applied_df, best_k, pca_model, scaler, scaled_data_wihtout_columns)


flow_pattern.plot_cluster_centroids(centroids_df, output_path=r"C:\Users\binia\OneDrive\Desktop\\4gmm\pic\finial_rep_patter")

flow_pattern.save_centroids(centroids_df, output_path)
flow_pattern.save_clusters_to_csv(data, cluster_labels, output_path=r"C:\Users\binia\OneDrive\Desktop\\4gmm\pic\finial_rep_patter")

flow_pattern.merge_on_date_and_save(
    r"C:\\Users\\binia\\OneDrive\\Desktop\\4gmm\\data\\All_average_flows&Temperature_cluster.csv", 
    r"C:\\Users\\binia\\OneDrive\\Desktop\\4gmm\\data\\All_Flow_Pattern_Dateweek_cluster.csv", 
    r"C:\\Users\\binia\\OneDrive\\Desktop\\4gmm\\data\\merged_data.csv"
)

merged_data = pd.read_csv(r"C:\\Users\\binia\\OneDrive\\Desktop\\4gmm\\data\\merged_data.csv")

# Perform basic analysis and boxplot of 'Average Flow' by cluster pattern
flow_pattern.analyze_cluster_patterns(merged_data, feature_column='Average Flow')




