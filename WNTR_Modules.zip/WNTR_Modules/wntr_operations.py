import wntr
import logging
from file_handling import modify_decay_coefficients

def base_demand_convert(inp_file_path, base_demand_values, node_name='90'):
    """
    Converts the base demand from L/s to GPM and m³/s and updates the demand values for a specific node.

    Parameters:
    - inp_file_path (str): Path to the INP file used to create the WaterNetworkModel.
    - base_demand_values (pd.Series): Series of base demand values in liters per second (L/s).
    - node_name (str): The name of the node to update in the water network. Default is '90'.

    Returns:
    - wn (wntr.network.WaterNetworkModel): The updated WaterNetworkModel instance.
    - scaling_factors (list): A list of scaling factors applied to the base demand for each iteration.
    """
    wn = wntr.network.WaterNetworkModel(inp_file_path)
    scaling_factors = []

    num_iterations = len(base_demand_values)
    logging.info(f"Processing {num_iterations} iterations for node {node_name}")

    for i in range(num_iterations):
        avg_flow_lps = base_demand_values.iloc[i]
        avg_flow_gpm = avg_flow_lps * 15.8503  # Convert L/s to GPM
        avg_flow_m3s = avg_flow_lps * 0.001  # Convert L/s to m³/s
        scaling_factor = avg_flow_gpm / 1000
        scaling_factors.append(scaling_factor)

        node = wn.get_node(node_name)
        node.demand_timeseries_list[0].base_value = avg_flow_m3s

        logging.info(f"Iteration {i+1}: Updated base demand for node {node_name} to {avg_flow_m3s} m³/s")

    return wn, scaling_factors

def update_all_nodes(wn, scaling_factors, node_of_interest='90'):
    """
    Updates the demand values for all nodes in the water network, applying the scaling factor
    from the node of interest to all other nodes.

    Parameters:
    - wn (wntr.network.WaterNetworkModel): The WaterNetworkModel instance.
    - scaling_factors (list): List of scaling factors for each iteration.
    - node_of_interest (str): The name of the node used to calculate the scaling factor. Default is '90'.

    Returns:
    - wn (wntr.network.WaterNetworkModel): The updated WaterNetworkModel instance.
    """
    num_iterations = len(scaling_factors)
    for i in range(num_iterations):
        scaling_factor = scaling_factors[i]
        for junction_name in wn.junction_name_list:
            if junction_name != node_of_interest:
                junction = wn.get_node(junction_name)
                junction.demand_timeseries_list[0].base_value *= scaling_factor
        logging.info(f"Iteration {i+1}: Updated all other nodes with scaling factor {scaling_factor}")

    return wn

def print_attributes(iteration, avg_flow_lps, node_name, wn, data_df, i):
    """
    Prints the base demand, demand pattern, and k value for a given iteration.

    Parameters:
    - iteration (int): The current iteration number.
    - avg_flow_lps (float): The average flow in liters per second (L/s) for the current iteration.
    - node_name (str): The name of the node of interest in the water network.
    - wn (wntr.network.WaterNetworkModel): The WaterNetworkModel instance.
    - data_df (pd.DataFrame): The DataFrame containing the data including 'k' values.
    - i (int): The current index within the DataFrame.

    Returns:
    - None: This function prints the attributes to the console.
    """
    logging.info(f"Iteration {iteration + 1}:")
    logging.info(f"  Base Demand at Node {node_name}: {avg_flow_lps} L/s")

    pattern_name = wn.get_node(node_name).demand_timeseries_list[0].pattern.name
    default_pattern = wn.get_pattern(pattern_name).multipliers
    logging.info(f"  Demand Pattern: {default_pattern}")

    specific_k = -data_df.iloc[i, data_df.columns.get_loc('k')]
    logging.info(f"  Bulk Decay Coefficient: {specific_k}")
    logging.info(f"  Wall Decay Coefficient: -0.1")

def apply_patterns(wn, node_of_interest, pattern_name):
    """
    Assigns the demand pattern to all nodes in the network except the specified node.

    Parameters:
    - wn (wntr.network.WaterNetworkModel): The WaterNetworkModel instance.
    - node_of_interest (str): The node that already has the pattern assigned.
    - pattern_name (str): The name of the demand pattern to be assigned.

    Returns:
    - wntr.network.WaterNetworkModel: The updated WaterNetworkModel instance with patterns applied.
    """
    for node_name in wn.node_name_list:
        node_object = wn.get_node(node_name)
        if isinstance(node_object, wntr.network.elements.Junction) and node_name != node_of_interest:
            node_object.demand_pattern_name = pattern_name
    
    return wn

def update_decay_coeff(inp_file_path, bulk_decay_coefficient, wall_decay_coefficient):
    """
    Updates the decay coefficients in the INP file, allowing for dynamic or static coefficients.

    Parameters:
    - inp_file_path (str): The path to the INP file.
    - bulk_decay_coefficient (float or callable): The bulk decay coefficient to be updated or a function to calculate it.
    - wall_decay_coefficient (float or callable): The wall decay coefficient to be updated or a function to calculate it.

    Returns:
    - None
    """
    # If bulk_decay_coefficient is callable, execute it to get the coefficient
    if callable(bulk_decay_coefficient):
        bulk_decay_coefficient = bulk_decay_coefficient()

    # If wall_decay_coefficient is callable, execute it to get the coefficient
    if callable(wall_decay_coefficient):
        wall_decay_coefficient = wall_decay_coefficient()

    modify_decay_coefficients(inp_file_path, wall_coeff=wall_decay_coefficient, bulk_coeff=bulk_decay_coefficient)

