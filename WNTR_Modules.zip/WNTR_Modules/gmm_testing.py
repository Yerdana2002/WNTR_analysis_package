import numpy as np
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture
import pandas as pd
from sklearn.preprocessing import StandardScaler

def apply_gmm(data, n_clusters=4, feature_column='Average Flow Scaled'):
    """
    Applies Gaussian Mixture Model (GMM) to the specified feature column.

    Parameters:
    - data (pd.DataFrame): The dataset containing the feature to cluster.
    - n_clusters (int): The number of clusters to fit the GMM. Default is 4.
    - feature_column (str): The column name of the feature to cluster. Default is 'Average Flow Scaled'.

    Returns:
    - data (pd.DataFrame): The dataset with cluster assignments and probabilities.
    - gmm (GaussianMixture): The fitted GMM model.
    """
    gmm = GaussianMixture(n_components=n_clusters, random_state=0).fit(data[[feature_column]])
    data['Cluster'] = gmm.predict(data[[feature_column]])
    probabilities = gmm.predict_proba(data[[feature_column]])

    # Add probabilities as new columns for each cluster
    for i in range(probabilities.shape[1]):
        data[f'Cluster_{i}_Prob'] = probabilities[:, i]

    return data, gmm


    

# Load your CSV file
file_path = r"C:\Users\binia\OneDrive\Desktop\BIG\Updated_Daily_Averages.csv"
data = pd.read_csv(file_path)

# Convert 'Date' column to datetime
data['Date'] = pd.to_datetime(data['Date'])

# Standardize the 'Average Flow' before applying GMM
scaler = StandardScaler()
data['Average Flow Scaled'] = scaler.fit_transform(data[['Average Flow']])

# Implement GMM on the scaled 'Average Flow' with 4 clusters
gmm = GaussianMixture(n_components=4, random_state=0).fit(data[['Average Flow Scaled']])
data['Cluster'] = gmm.predict(data[['Average Flow Scaled']])

# Obtain the mean of 'Average Flow' for each cluster
cluster_means = data.groupby('Cluster')['Average Flow'].mean().sort_values()

# Map numerical clusters to names based on the sorted means
cluster_mapping = {idx: name for idx, name in zip(cluster_means.index, ['Low', 'Lower-Medium', 'Upper-Medium', 'High'])}
data['Cluster Name'] = data['Cluster'].map(cluster_mapping)

# Now let's plot the 'Average Flow' with the cluster assignments over 'Date'
plt.figure(figsize=(10, 6))
colors = ['green', 'blue', 'yellow', 'orange']  # Adding a fourth color for the additional cluster
for cluster_number, cluster_name in cluster_mapping.items():
    cluster_data = data[data['Cluster'] == cluster_number]
    plt.scatter(cluster_data['Date'], cluster_data['Average Flow'], 
                label=f'Cluster {cluster_name}', color=colors[cluster_number], alpha=0.5)
# Calculate the probabilities of each data point belonging to each cluster
# Invert the cluster_mapping dictionary to get cluster names to indices
inverse_cluster_mapping = {v: k for k, v in cluster_mapping.items()}

# Add probabilities to your DataFrame for better visibility (optional)
data['Low Cluster Probability'] = probabilities[:, inverse_cluster_mapping['Low']]

# Set a threshold for selecting data points strictly in the 'Low' cluster
threshold = 0.9

# Filter data points where the probability of being in the 'Low' cluster is above the threshold
strictly_low_data = data[data['Low Cluster Probability'] > threshold]

# Example of what to do with this data: Print it or save it to a new CSV
print(strictly_low_data)  # For viewing or further analysis

# Optionally, save these strictly low data points to a new CSV file
strictly_low_file_path = r"C:\Users\binia\OneDrive\Desktop\4gmm\data\Strictly_Low_Cluster.csv"
strictly_low_data.to_csv(strictly_low_file_path, index=False)


plt.xlabel('Date')
plt.ylabel('Average Flow[L/Sec]')
plt.legend()
plt.gcf().autofmt_xdate()  # Auto-format the dates on the x-axis for better readability
plt.savefig(r"C:\Users\binia\OneDrive\Desktop\4gmm\pic\finial_gmm", dpi=300)
plt.show()

# Save the DataFrame with the added 'Cluster Name' column back to a CSV file
updated_file_path = r"C:\Users\binia\OneDrive\Desktop\4gmm\data\All_average_flows&Temperature_cluster.csv"
data.to_csv(updated_file_path, index=False)