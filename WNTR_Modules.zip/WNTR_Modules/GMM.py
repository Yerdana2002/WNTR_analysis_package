import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
import os

def apply_gmm(data, n_clusters=4, feature_column='Average Flow Scaled'):
    """
    Applies Gaussian Mixture Model (GMM) to the specified feature column.

    Parameters:
    - data (pd.DataFrame): The dataset containing the feature to cluster.
    - n_clusters (int): The number of clusters to fit the GMM. Default is 4.
    - feature_column (str): The column name of the feature to cluster. Default is 'Average Flow Scaled'.

    Returns:
    - data (pd.DataFrame): The dataset with cluster assignments and probabilities.
    - gmm (GaussianMixture): The fitted GMM model.
    """
    gmm = GaussianMixture(n_components=n_clusters, random_state=0).fit(data[[feature_column]])
    data['Cluster'] = gmm.predict(data[[feature_column]])
    probabilities = gmm.predict_proba(data[[feature_column]])

    # Add probabilities as new columns for each cluster
    for i in range(probabilities.shape[1]):
        data[f'Cluster_{i}_Prob'] = probabilities[:, i]

    return data, gmm

def find_optimal_clusters(data, feature_column='Average Flow Scaled', max_clusters=10):
    """
    Finds the optimal number of clusters for GMM based on BIC and AIC scores.

    Parameters:
    - data (pd.DataFrame): The dataset containing the feature to cluster.
    - feature_column (str): The column name of the feature to cluster. Default is 'Average Flow Scaled'.
    - max_clusters (int): The maximum number of clusters to evaluate. Default is 10.

    Returns:
    - optimal_clusters (int): The optimal number of clusters based on BIC and AIC scores.
    - bic_scores (list): The BIC scores for each number of clusters.
    - aic_scores (list): The AIC scores for each number of clusters.
    """
    bic_scores = []
    aic_scores = []

    for n in range(1, max_clusters + 1):
        gmm = GaussianMixture(n_components=n, random_state=0).fit(data[[feature_column]])
        bic_scores.append(gmm.bic(data[[feature_column]]))
        aic_scores.append(gmm.aic(data[[feature_column]]))

    optimal_clusters = np.argmin(bic_scores) + 1

    # Plotting BIC and AIC scores
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, max_clusters + 1), bic_scores, label='BIC', marker='o')
    plt.plot(range(1, max_clusters + 1), aic_scores, label='AIC', marker='o')
    plt.xlabel('Number of Clusters')
    plt.ylabel('Score')
    plt.legend()
    plt.title('BIC and AIC Scores by Number of Clusters')
    plt.show()

    print(f"Optimal number of clusters based on BIC: {optimal_clusters}")
    return optimal_clusters, bic_scores, aic_scores

def split_and_save_clusters(data, cluster_mapping, base_path, feature_column='Average Flow'):
    """
    Splits the data into clusters based on GMM results and saves each cluster to a separate CSV file.

    Parameters:
    - data (pd.DataFrame): The dataset containing the cluster assignments.
    - cluster_mapping (dict): A dictionary mapping cluster indices to cluster names.
    - base_path (str): The directory where the cluster data should be saved.
    - feature_column (str): The column name of the feature used in clustering. Default is 'Average Flow'.

    Returns:
    - None
    """
    for cluster_number, cluster_name in cluster_mapping.items():
        cluster_data = data[data['Cluster'] == cluster_number]

        # Construct the file path
        file_path = os.path.join(base_path, f"{cluster_name.replace(' ', '_')}_cluster_data.csv")

        # Save the filtered cluster data to CSV
        cluster_data[['Date', feature_column]].to_csv(file_path, index=False)
        print(f"{cluster_name} cluster data saved to {file_path}")


def plot_gmm_membership(data, gmm, feature_column='Average Flow Scaled', output_path=None):
    """
    Plots the GMM membership functions for each cluster.

    Parameters:
    - data (pd.DataFrame): The dataset containing the feature to plot.
    - gmm (GaussianMixture): The fitted GMM model.
    - feature_column (str): The column name of the feature to plot. Default is 'Average Flow Scaled'.
    - output_path (str): Optional path to save the plot as an image. If None, the plot is displayed.

    Returns:
    - None
    """
    flow_values = data[feature_column].values.reshape(-1, 1)

    # Sort components by their means
    sorted_indices = np.argsort(gmm.means_.flatten())
    sorted_means = gmm.means_.flatten()[sorted_indices]
    sorted_covariances = gmm.covariances_[sorted_indices]
    sorted_weights = gmm.weights_[sorted_indices]

    labels = ['Low', 'Lower-Medium', 'Upper-Medium', 'High']
    x = np.linspace(flow_values.min(), flow_values.max(), 1000).reshape(-1, 1)

    def gaussian_pdf(x, mean, cov):
        cov = np.diag(cov) if cov.ndim == 1 else cov
        inv_cov = np.linalg.inv(cov)
        diff = x - mean
        return np.exp(-0.5 * np.sum(diff @ inv_cov * diff, axis=1)) / np.sqrt((2 * np.pi) ** len(mean) * np.linalg.det(cov))

    pdfs = np.zeros((x.shape[0], gmm.n_components))
    for i in range(gmm.n_components):
        pdfs[:, i] = sorted_weights[i] * gaussian_pdf(x, sorted_means[i].reshape(-1), sorted_covariances[i])

    normalized_pdfs = pdfs / pdfs.max(axis=0)

    plt.figure(figsize=(6, 4))
    for i in range(4):
        plt.plot(x, normalized_pdfs[:, i], label=labels[i])

    plt.xlabel('Flow Value [L/sec]')
    plt.ylabel('Normalized Probability Density')
    plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.15), ncol=4)

    if output_path:
        plt.savefig(output_path, dpi=300)
    else:
        plt.show()

def analyze_cluster_normality(base_path, clusters, feature_column='Average Flow', output_path=None):
    """
    Analyzes the normality of each cluster using histograms and Q-Q plots.

    Parameters:
    - base_path (str): The directory where the cluster data CSV files are stored.
    - clusters (list): List of cluster names corresponding to the CSV files.
    - feature_column (str): The column name of the feature to analyze. Default is 'Average Flow'.
    - output_path (str): Optional path to save the plot as an image. If None, the plot is displayed.

    Returns:
    - None
    """
    plt.figure(figsize=(12, 8))

    for i, cluster in enumerate(clusters):
        file_path = os.path.join(base_path, f"{cluster.replace(' ', '_')}_cluster_data.csv")
        cluster_data = pd.read_csv(file_path)
        cluster_data['Date'] = pd.to_datetime(cluster_data['Date'])

        plt.subplot(2, 4, 2 * i + 1)
        plt.hist(cluster_data[feature_column], bins=20, alpha=0.7, color='blue', edgecolor='black')
        plt.title(f'Histogram - {cluster}')
        plt.xlabel(f'{feature_column} [L/sec]')
        plt.ylabel('Frequency')

        plt.subplot(2, 4, 2 * i + 2)
        stats.probplot(cluster_data[feature_column], dist="norm", plot=plt)
        plt.title(f'Q-Q Plot - {cluster}')

        shapiro_test = stats.shapiro(cluster_data[feature_column])
        print(f"Shapiro-Wilk Test for {cluster} Cluster:")
        print(f"Statistic: {shapiro_test.statistic:.4f}, p-value: {shapiro_test.pvalue:.4f}")

    plt.tight_layout()

    if output_path:
        plt.savefig(output_path, dpi=300)
    else:
        plt.show()

def run_gmm_clustering(file_path, base_path, feature_column='Average Flow', max_clusters=10):
    """
    High-level function to run GMM clustering and save results.

    Parameters:
    - file_path (str): Path to the CSV file containing the data.
    - base_path (str): Directory where cluster data will be saved.
    - feature_column (str): The column name of the feature to cluster. Default is 'Average Flow'.
    - max_clusters (int): The maximum number of clusters to evaluate. Default is 10.

    Returns:
    - None, saves files of individual clusters
    """
    data = pd.read_csv(file_path)
    data['Date'] = pd.to_datetime(data['Date'])

    scaler = StandardScaler()
    data[f'{feature_column} Scaled'] = scaler.fit_transform(data[[feature_column]])

    optimal_clusters, bic_scores, aic_scores = find_optimal_clusters(data, feature_column=f'{feature_column} Scaled', max_clusters=max_clusters)

    data, gmm = apply_gmm(data, n_clusters=optimal_clusters, feature_column=f'{feature_column} Scaled')

    cluster_means = data.groupby('Cluster')[feature_column].mean().sort_values()

    cluster_mapping = {idx: name for idx, name in zip(cluster_means.index, ['Low', 'Lower-Medium', 'Upper-Medium', 'High'])}
    data['Cluster Name'] = data['Cluster'].map(cluster_mapping)

    plt.figure(figsize=(10, 6))
    colors = ['green', 'blue', 'yellow', 'orange']
    for cluster_number, cluster_name in cluster_mapping.items():
        cluster_data = data[data['Cluster'] == cluster_number]
        plt.scatter(cluster_data['Date'], cluster_data[feature_column], label=f'Cluster {cluster_name}', color=colors[cluster_number], alpha=0.5)
    plt.xlabel('Date')
    plt.ylabel(f'{feature_column} [L/Sec]')
    plt.legend()
    plt.gcf().autofmt_xdate()
    plt.show()

    split_and_save_clusters(data, cluster_mapping, base_path, feature_column=feature_column)
