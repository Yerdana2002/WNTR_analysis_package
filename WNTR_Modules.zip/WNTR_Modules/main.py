import os
import pandas as pd
from file_handling import read_data_csv, save_results
from wntr_operations import base_demand_convert, update_all_nodes, print_attributes, apply_patterns, update_decay_coeff
from simulation import simulate_concentration, filter_concentration


def run_water_network_simulation(inp_file_path, data_file_path, output_base_dir, node_of_interest='90', 
                                 bulk_decay_coefficient=-2, wall_decay_coefficient=-0.1, pattern_name=None, 
                                 start_time=24, end_time=48, save_as_csv=True):
    """
    Higher-level function that combines all the steps for running a water network simulation.

    Parameters:
    - inp_file_path (str): Path to the INP file.
    - data_file_path (str): Path to the CSV file containing the data.
    - output_base_dir (str): Directory where results should be saved.
    - node_of_interest (str): The node used for scaling factors and concentration measurements. Default is '90'.
    - bulk_decay_coefficient (float or callable): The bulk decay coefficient (or function to calculate it).
    - wall_decay_coefficient (float or callable): The wall decay coefficient (or function to calculate it).
    - pattern_name (str): Name of the demand pattern to be applied. Default is None.
    - start_time (int): Start time for filtering results (in hours). Default is 24.
    - end_time (int): End time for filtering results (in hours). Default is 48.
    - save_as_csv (bool): Whether to save the results as CSV. Default is True.

    Returns:
    - None
    """

    # Step 1: Read data from the CSV file and calculate the average 'k' value
    data_df, average_k = read_data_csv(data_file_path)

    # Step 2: Initialize the WaterNetworkModel and update base demand
    wn, scaling_factors = base_demand_convert(inp_file_path, data_df['Average Flow'], node_name=node_of_interest)
    
    # Step 3: Update demand values for all nodes using the calculated scaling factors
    wn = update_all_nodes(wn, scaling_factors, node_of_interest=node_of_interest)

    # Step 4: Print attributes for verification
    for i in range(len(data_df)):
        print_attributes(i, data_df['Average Flow'].iloc[i], node_of_interest, wn, data_df, i)

    # Step 5: Apply demand patterns if specified
    if pattern_name:
        wn = apply_patterns(wn, node_of_interest=node_of_interest, pattern_name=pattern_name)

    # Step 6: Update decay coefficients in the INP file
    update_decay_coeff(inp_file_path, bulk_decay_coefficient, wall_decay_coefficient)

    # Step 7: Run the simulation and get the concentration results
    chlorine_concentration, time_hours = simulate_concentration(wn, node_name=node_of_interest, attribute='quality')

    # Step 8: Filter the concentration results for the specified time interval
    filtered_concentrations = filter_concentration(chlorine_concentration, time_hours, start_time, end_time, cluster_name='Simulation')

    # Step 9: Save the results to the specified output directory
    if filtered_concentrations:
        transformed_data = pd.DataFrame(filtered_concentrations, columns=['0'])
        save_results(output_base_dir, transformed_data, save_as_csv=save_as_csv)
    else:
        print("No data to save after filtering the results.")
