from file_handling import read_data_csv, save_results, modify_decay_coefficients
from wntr_operations import base_demand_convert, update_all_nodes, print_attributes, apply_patterns
from simulation import simulate_concentration, filter_concentration

def run_wntr_simulation(inp_file_path, data_file_path, output_dir, node_name='90', attribute='quality'):
    # Step 1: Load Data and Calculate Average k
    data_df, average_k = read_data_csv(data_file_path, calculate_k=True)

    # Step 2: Initialize a list to store chlorine concentration series for each iteration
    all_chlorine_values = []

    # Step 3: Process Each Iteration
    base_demand_values_lps = data_df['Average Flow']
    num_iterations = len(base_demand_values_lps)
    print(f"Processing with {num_iterations} iterations")

    for i in range(num_iterations):
        # Step 3a: Convert Base Demand and Update All Nodes
        wn, scaling_factors = base_demand_convert(inp_file_path, base_demand_values_lps)
        wn = update_all_nodes(wn, scaling_factors, node_name)

        # Step 3b: Print Attributes
        print_attributes(i, base_demand_values_lps.iloc[i], node_name, wn, data_df, i)

        # Step 3c: Apply Patterns to All Nodes
        pattern_name = wn.get_node(node_name).demand_timeseries_list[0].pattern.name
        wn = apply_patterns(wn, node_name, pattern_name)

        # Step 3d: Update Decay Coefficients
        bulk_decay_coefficient = -average_k
        wall_decay_coefficient = -0.1
        modify_decay_coefficients(inp_file_path, wall_decay_coefficient, bulk_decay_coefficient)

        # Step 3e: Run Simulation and Filter Concentrations
        concentration, time_hours = simulate_concentration(wn, node_name, attribute)
        filtered_concentrations = filter_concentration(concentration, time_hours, start_time=24, end_time=48, i=i, cluster_name='High')

        if filtered_concentrations:
            all_chlorine_values.extend(filtered_concentrations)

    # Step 4: Save Results
    transformed_data = pd.DataFrame(all_chlorine_values, columns=['0'])
    save_results(output_dir, transformed_data)

# Example Usage:
run_wntr_simulation(inp_file_path, data_file_path, output_dir=r"C:\Users\binia\OneDrive\Desktop\4gmm\simulation\High")
