import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import silhouette_score, silhouette_samples
import matplotlib.cm as cm
import seaborn as sns
from scipy.stats import chi2_contingency

def preprocess_data(file_path, drop_columns=['Day_of_week']):
    data = pd.read_csv(file_path)
    date_column = data['Date'].copy()  # Store the 'Date' column
    scaled_data = data.drop(columns=drop_columns)
    
    scaler = StandardScaler()
    data_scaled = scaler.fit_transform(scaled_data)
    print("Returning from preprocess_data:", data_scaled.shape, len(scaled_data.columns), scaler)
    
    return pd.DataFrame(data_scaled, columns=scaled_data.columns), scaled_data, scaler, date_column





def apply_pca(data_scaled, variance_threshold=0.80):
    """
    Applies PCA to the data to reduce dimensionality.

    Parameters:
    - data_scaled (pd.DataFrame): The scaled data.
    - variance_threshold (float): The percentage of variance to retain. Default is 0.80.

    Returns:
    - pd.DataFrame: The PCA reduced data.
    - PCA: The PCA model for potential inverse transformations.
    """
    pca = PCA(n_components=variance_threshold)
    data_reduced = pca.fit_transform(data_scaled)
    print("Selected components:", pca.n_components_)
    return pd.DataFrame(data_reduced), pca

def determine_optimal_clusters(data_reduced, max_clusters=10):
    """
    Determines the optimal number of clusters using silhouette scores.

    Parameters:
    - data_reduced (pd.DataFrame): The PCA reduced data.
    - max_clusters (int): The maximum number of clusters to evaluate. Default is 10.

    Returns:
    - int: The optimal number of clusters.
    """
    best_k = 2
    best_score = -1

    for K in range(2, max_clusters + 1):
        clusterer = KMeans(n_clusters=K, random_state=10)
        cluster_labels = clusterer.fit_predict(data_reduced)
        silhouette_avg = silhouette_score(data_reduced, cluster_labels)
        
        if silhouette_avg > best_score:
            best_k = K
            best_score = silhouette_avg

        print(f"For n_clusters = {K}, the average silhouette_score is: {silhouette_avg}")

    return best_k

def plot_silhouette(data_reduced, optimal_k):
    """
    Plots the silhouette analysis for the optimal number of clusters.

    Parameters:
    - data_reduced (pd.DataFrame): The PCA reduced data.
    - optimal_k (int): The optimal number of clusters.

    Returns:
    - None
    """
    clusterer = KMeans(n_clusters=optimal_k, random_state=10)
    cluster_labels = clusterer.fit_predict(data_reduced)
    silhouette_avg = silhouette_score(data_reduced, cluster_labels)
    sample_silhouette_values = silhouette_samples(data_reduced, cluster_labels)

    fig, ax = plt.subplots(figsize=(8, 6))
    y_lower = 10
    for i in range(optimal_k):
        ith_cluster_silhouette_values = sample_silhouette_values[cluster_labels == i]
        ith_cluster_silhouette_values.sort()
        size_cluster_i = ith_cluster_silhouette_values.shape[0]
        y_upper = y_lower + size_cluster_i
        color = cm.nipy_spectral(float(i) / optimal_k)
        ax.fill_betweenx(np.arange(y_lower, y_upper), 0, ith_cluster_silhouette_values,
                         facecolor=color, edgecolor=color, alpha=0.7)
        ax.text(-0.05, y_lower + 0.5 * size_cluster_i, str(i))
        y_lower = y_upper + 10

    ax.axvline(x=silhouette_avg, color="red", linestyle="--")
    ax.set_xlabel("Silhouette coefficient values")
    ax.set_ylabel("Cluster label")
    ax.set_yticks([])  
    ax.set_xticks(np.arange(-0.1, 1.1, 0.2))
    plt.tight_layout()
    plt.show()

def kmeans_clustering(data_reduced, optimal_k, pca, scaler, original_data):
    """
    Applies K-Means clustering on the reduced data and maps clusters back to original feature space.

    Parameters:
    - data_reduced (pd.DataFrame): The PCA reduced data.
    - optimal_k (int): The optimal number of clusters.
    - pca (PCA): The PCA model for inverse transformations.
    - scaler (StandardScaler): The scaler used for original data scaling.
    - original_data (pd.DataFrame): The original data before scaling without columns.

    Returns:
    - pd.DataFrame: The cluster centroids in the original feature space.
    - pd.Series: The cluster labels for each data point.
    """
    kmeans = KMeans(n_clusters=optimal_k, random_state=0)
    kmeans.fit(data_reduced)

    cluster_centers_reduced = kmeans.cluster_centers_
    cluster_centers_original = pca.inverse_transform(cluster_centers_reduced)
    cluster_centers_original = scaler.inverse_transform(cluster_centers_original)
    cluster_centers_original = np.round(cluster_centers_original, 2)

    centroids_df = pd.DataFrame(cluster_centers_original, columns=original_data.columns)
    centroids_df.index += 1

    cluster_labels = pd.Series(kmeans.predict(data_reduced) + 1)

    return centroids_df, cluster_labels


def plot_cluster_centroids(centroids_df, output_path=None):
    """
    Plots the cluster centroids.

    Parameters:
    - centroids_df (pd.DataFrame): The DataFrame containing the cluster centroids.
    - output_path (str): The path to save the plot. If None, the plot is shown.

    Returns:
    - None
    """
    fig, ax = plt.subplots(figsize=(6, 4))
    time_indices = np.arange(centroids_df.shape[1])

    for i, center in centroids_df.iterrows():
        ax.plot(time_indices, center, label=f'Cluster {i}', marker='o')

    ax.set_xticks(time_indices)
    ax.set_xticklabels([f'{i:02}:00' for i in range(24)], rotation=90)
    ax.set_xlabel('Time of Day')
    ax.set_ylabel('Demand Multiplier')
    ax.legend()
    plt.tight_layout()

    if output_path:
        plt.savefig(output_path)
    else:
        plt.show()

def save_centroids(centroids_df, output_path):
    """
    Saves the cluster centroids to a CSV file.

    Parameters:
    - centroids_df (pd.DataFrame): The DataFrame containing the cluster centroids.
    - output_path (str): The path to save the CSV file.

    Returns:
    - None
    """
    centroids_df.to_csv(output_path, index_label="Cluster")
    print(f"Centroids saved to {output_path}")

def save_clusters_to_csv(data, date_column, cluster_labels, output_file_path):
    data['Date'] = date_column  # Properly add back the 'Date'
    data['Cluster'] = cluster_labels + 1  # Ensure labels are properly aligned
    
    data.to_csv(output_file_path, index=False)
    print(f"CSV file has been updated with cluster labels and saved to: {output_file_path}")




def merge_and_analyze(df1_path, df2_path, output_path):
    df1 = pd.read_csv(df1_path)
    df2 = pd.read_csv(df2_path)

    # Convert 'Date' columns to datetime format
    df1['Date'] = pd.to_datetime(df1['Date']).dt.date
    df2['Date'] = pd.to_datetime(df2['Date']).dt.date

    # Check and rename 'Cluster' column to 'Cluster_Pattern' in df2 if necessary
    if 'Cluster' in df2.columns:
        df2.rename(columns={'Cluster': 'Cluster_Pattern'}, inplace=True)
    else:
        print("Warning: 'Cluster' column not found in df2 to rename to 'Cluster_Pattern'")

    # Verify columns before merging
    print("Columns in df1:", df1.columns)
    print("Columns in df2:", df2.columns)

    # Merge the dataframes
    merged_df = pd.merge(df1, df2, on='Date', how='inner')

    # Confirm columns after merging
    print("Columns after merging:", merged_df.columns)

    # Save the merged DataFrame
    merged_df.to_csv(output_path, index=False)
    print(f"Merged data saved to {output_path}")
    
    return merged_df




def full_flow_pattern_analysis(file_path, average_flows_path, output_dir, cluster_paths, variance_threshold=0.80, max_clusters=10, expected_probabilities=None, representative_patterns_path=None):
    # Step 1: Preprocess data
    print("Step 1: Preprocessing data...")
    data_scaled, original_data, scaler, date_column = preprocess_data(file_path, drop_columns=['Date', 'Day_of_week'])

    # Step 2: Apply PCA
    print("Step 2: Applying PCA...")
    data_reduced, pca_model = apply_pca(data_scaled, variance_threshold)

    # Step 3: Determine optimal number of clusters using silhouette scores
    print("Step 3: Determining optimal number of clusters...")
    optimal_k = determine_optimal_clusters(data_reduced, max_clusters)

    # Step 4: Plot silhouette analysis
    print("Step 4: Plotting silhouette analysis...")
    plot_silhouette(data_reduced, optimal_k)

    # Step 5: Apply KMeans clustering
    print(f"Step 5: Applying KMeans clustering with {optimal_k} clusters...")
    cluster_centroids, cluster_labels = kmeans_clustering(data_reduced, optimal_k, pca_model, scaler, original_data)

    # Step 6: Save centroids to CSV
    print("Step 6: Saving centroids to CSV...")
    centroids_output_path = os.path.join(output_dir, "representative_demand_patterns.csv")
    save_centroids(cluster_centroids, centroids_output_path)

    # Step 7: Plot cluster centroids
    print("Step 7: Plotting cluster centroids...")
    plot_cluster_centroids(cluster_centroids, os.path.join(output_dir, "demand_pattern_plot.png"))

    # Step 8: Save clusters to CSV with cluster labels
    print("Step 8: Saving clusters with labels to CSV...")
    clusters_output_path = os.path.join(output_dir, "All_Flow_Pattern_Dateweek_cluster.csv")
    save_clusters_to_csv(data=original_data, date_column=date_column, cluster_labels=cluster_labels, output_file_path=clusters_output_path)

    # Step 9: Merge datasets using merge_and_analyze
    print("Step 9: Merging datasets...")
    df1_path = average_flows_path  # Path to average flows & temperature
    df2_path = clusters_output_path  # Path to clusters data
    merged_output_path = os.path.join(output_dir, "merged_data.csv")
    merged_data = merge_and_analyze(df1_path, df2_path, merged_output_path)
    print("Columns in merged data:", merged_data.columns)

    # Step 10: Analyze cluster patterns
    analyze_cluster_patterns(merged_data, output_dir)

    # Step 11: Filter and save flow patterns for each cluster
    print("Step 11: Filtering and saving flow patterns for each cluster...")
    filter_flow_patterns_and_save(cluster_paths, clusters_output_path, output_dir)

    # Step 12: Compare actual vs. expected probabilities (if provided)
    if expected_probabilities:
        print("Step 12: Comparing actual to expected probabilities...")
        compare_actual_to_expected_probabilities(merged_data, 'High', expected_probabilities)

    # Step 13: Filter representative patterns (if path provided)
    if representative_patterns_path:
        print("Step 13: Filtering representative patterns...")
        filtered_patterns = filter_representative_patterns(representative_patterns_path, [1, 2, 3])
        filtered_patterns_output_path = os.path.join(output_dir, "filtered_representative_patterns.csv")
        filtered_patterns.to_csv(filtered_patterns_output_path, index=False)
        print(f"Filtered representative patterns saved to {filtered_patterns_output_path}")

    print("Full flow pattern analysis complete!")




def analyze_cluster_patterns(merged_df, output_dir=None, feature_column='Average Flow'):
    """
    Performs a basic analysis of cluster patterns and generates a boxplot for visualizing 'Average Flow' by cluster pattern.

    Parameters:
    - merged_df (pd.DataFrame): The merged DataFrame containing 'Cluster Name' and 'Cluster_Pattern'.
    - output_dir (str): Directory to save output plots. If None, the plot is shown but not saved.
    - feature_column (str): The feature column to analyze (default: 'Average Flow').

    Returns:
    - None
    """
    # Display basic summary statistics
    print(f"\n{feature_column} Summary Statistics:")
    print(merged_df[feature_column].describe())

    # Count of instances in each Cluster Pattern
    print("\nCount of instances in each Cluster Pattern:")
    print(merged_df['Cluster_Pattern'].value_counts())

    # Boxplot of the feature_column by Cluster Pattern
    sns.boxplot(x='Cluster_Pattern', y=feature_column, data=merged_df)
    plt.title(f'{feature_column} by Cluster Pattern')
    
    # Save the plot to the output directory if provided
    if output_dir:
        boxplot_output_path = os.path.join(output_dir, f"{feature_column}_by_Cluster_Pattern.png")
        plt.savefig(boxplot_output_path, dpi=300)
        print(f"Boxplot saved to {boxplot_output_path}")
    else:
        plt.show()

def analyze_cluster_pattern_distribution(data, output_base_dir):
    """
    Analyzes the association between cluster names and cluster patterns by:
    1. Cross-tabulation of cluster name and pattern.
    2. Saving percentage data of cluster patterns for each cluster.
    3. Generating a heatmap of the cross-tabulation.
    4. Conducting a Chi-square test of independence.
    """
    # Step 1: Cross-tabulation
    cross_tab = pd.crosstab(data['Cluster Name'], data['Cluster_Pattern'])

    # Save cross-tabulated data as percentages
    percentage_tab = cross_tab.div(cross_tab.sum(axis=1), axis=0)
    percentage_output_path = os.path.join(output_base_dir, "pattern_probabilities.csv")
    percentage_tab.to_csv(percentage_output_path)
    print(f"Pattern probabilities saved to {percentage_output_path}")

    # Step 2: Heatmap of the Cross-tabulation
    plt.figure(figsize=(10, 6))
    sns.heatmap(cross_tab, annot=True, cmap='viridis', fmt='g')
    plt.ylabel('Base Demand Cluster')
    plt.xlabel('Representative Hourly Flow Pattern')
    heatmap_output_path = os.path.join(output_base_dir, "final_heatmap.png")
    plt.savefig(heatmap_output_path, dpi=300)
    plt.show()
    print(f"Heatmap saved to {heatmap_output_path}")

    # Step 3: Chi-Square Test of Independence
    chi2, p_value, dof, expected = chi2_contingency(cross_tab)
    print(f"Chi-Square Statistic: {chi2}, P-value: {p_value}")

    # Interpretation of the P-value
    if p_value < 0.05:
        print("There is a significant association between Cluster Name and Cluster Pattern.")
    else:
        print("There is no significant association between Cluster Name and Cluster Pattern.")

    return percentage_tab


import os
import pandas as pd



def filter_flow_patterns_and_save(cluster_paths, flow_pattern_path, output_base_dir):
    """
    Filters flow patterns based on the clusters and saves the filtered flow pattern for each cluster.
    """
    # Load all flow pattern data
    all_flow_pattern_df = pd.read_csv(flow_pattern_path)

    # Check if the 'Date' column exists and is properly formatted
    if 'Date' not in all_flow_pattern_df.columns:
        raise KeyError("'Date' column not found in the flow pattern data. Please ensure the 'Date' column is present.")

    # Ensure the 'Date' column is in the correct datetime format
    all_flow_pattern_df['Date'] = pd.to_datetime(all_flow_pattern_df['Date'], errors='coerce').dt.date

    # Loop through each cluster and filter
    for cluster_name, cluster_data_path in cluster_paths.items():
        # Load cluster data
        cluster_df = pd.read_csv(cluster_data_path)

        # Ensure the 'Date' column in the cluster data is also in datetime format
        if 'Date' not in cluster_df.columns:
            raise KeyError(f"'Date' column not found in the {cluster_name} cluster data.")

        cluster_df['Date'] = pd.to_datetime(cluster_df['Date'], errors='coerce').dt.date

        # Extract dates for this cluster
        cluster_dates = cluster_df['Date']

        # Filter flow pattern data for the dates found in the cluster
        filtered_flow_patterns = all_flow_pattern_df[all_flow_pattern_df['Date'].isin(cluster_dates)]

        # Select only the 'Date' column and flow pattern columns (0 hour to 23 hour)
        filtered_flow_patterns = filtered_flow_patterns[['Date'] + [f'{hour} hour' for hour in range(24)]]

        # Save the filtered flow pattern data to a new CSV file
        output_filtered_patterns_path = os.path.join(output_base_dir, f"filtered_{cluster_name.lower()}_cluster_flow_patterns.csv")
        filtered_flow_patterns.to_csv(output_filtered_patterns_path, index=False)
        print(f"Filtered flow pattern data saved to {output_filtered_patterns_path}")

def filter_and_save_patterns(cluster_name, cluster_path, all_flow_pattern_df, output_base_path):
    """
    Filters flow patterns based on the dates in the cluster data and saves the result.

    Parameters:
    - cluster_name (str): The name of the cluster.
    - cluster_path (str): Path to the cluster's CSV file.
    - all_flow_pattern_df (pd.DataFrame): DataFrame containing all flow pattern data.
    - output_base_path (str): Base path where filtered patterns are saved.

    Returns:
    - None
    """
    # Load the cluster data
    cluster_df = pd.read_csv(cluster_path)

    # Extract the dates from the cluster data
    cluster_dates = cluster_df['Date']

    # Filter the flow pattern data for the dates found in the cluster
    filtered_flow_patterns = all_flow_pattern_df[all_flow_pattern_df['Date'].isin(cluster_dates)]

    # Select only the columns from 'Date' and hours (0 to 23)
    filtered_flow_patterns = filtered_flow_patterns[['Date'] + [f'{hour} hour' for hour in range(24)]]

    # Save the filtered flow pattern data to a new CSV file
    output_filtered_patterns_path = os.path.join(output_base_path, f"filtered_{cluster_name.lower()}_cluster_flow_patterns.csv")
    filtered_flow_patterns.to_csv(output_filtered_patterns_path, index=False)
    print(f"Filtered flow pattern data saved to {output_filtered_patterns_path}")





def load_and_filter_data(complete_data_path, cluster_name): # Updated version with exception handling wrap around
    try:
        complete_data = pd.read_csv(complete_data_path)
        if 'Cluster Name' not in complete_data.columns or 'Date' not in complete_data.columns:
            raise ValueError("Missing required columns: 'Cluster Name' or 'Date'")
        cluster_dates = complete_data[complete_data['Cluster Name'] == cluster_name]['Date']
        filtered_data = complete_data[complete_data['Date'].isin(cluster_dates)]
        return filtered_data
    except FileNotFoundError:
        raise FileNotFoundError(f"File not found: {complete_data_path}")
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def compare_actual_to_expected_probabilities(data, cluster_name, expected_probabilities):
    """
    Compares the actual distribution of flow patterns for a given cluster to expected probabilities.
    """
    # Filter data for the specified cluster
    cluster_data = data[data['Cluster Name'] == cluster_name]

    # Get the actual distribution of flow patterns
    actual_pattern_distribution = cluster_data['Cluster_Pattern'].value_counts(normalize=True)

    print(f"Actual Pattern Distribution for {cluster_name} Cluster:")
    print(actual_pattern_distribution)

    # Compare actual distribution with expected probabilities
    for pattern, expected_prob in expected_probabilities.items():
        actual_prob = actual_pattern_distribution.get(pattern, 0)
        print(f"Pattern {pattern}: Expected Probability = {expected_prob}, Actual Probability = {actual_prob}")



def filter_representative_patterns(representative_patterns_path, clusters_to_include):
    """
    Filters the representative demand patterns based on specified clusters.

    Parameters:
    - representative_patterns_path (str): Path to the representative demand patterns CSV file.
    - clusters_to_include (list): List of cluster numbers to include in the filtered data.

    Returns:
    - pd.DataFrame: The filtered demand patterns.
    """
    representative_patterns_df = pd.read_csv(representative_patterns_path)
    filtered_patterns = representative_patterns_df[representative_patterns_df['Cluster'].isin(clusters_to_include)]
    
    return filtered_patterns #doesn't

def merge_flow_pattern_and_average_flow(flow_pattern_path, average_flows_path, output_path):
    """
    Merges the flow pattern data with average flow data based on the 'Date' column.
    """
    flow_pattern_df = pd.read_csv(flow_pattern_path)
    average_flows_df = pd.read_csv(average_flows_path)

    # Perform the merging logic
    merged_df = pd.merge(flow_pattern_df, average_flows_df, on='Date', how='inner')

    # Save the merged DataFrame
    merged_df.to_csv(output_path, index=False)
    print(f"Combined dataset saved to {output_path}")

    # Return the merged DataFrame
    return merged_df




def merge_and_save_data(cluster_name, paths):
    """
    Merges the filtered flow patterns with cluster data and saves the combined data.

    Parameters:
    - cluster_name (str): Name of the cluster.
    - paths (dict): Dictionary containing paths for each cluster's filtered patterns, cluster data, and output.

    Returns:
    - None
    """
    # Load the filtered patterns and cluster data
    filtered_patterns_df = pd.read_csv(paths['filtered_patterns'])
    cluster_data_df = pd.read_csv(paths['cluster_data'])

    # Merge the dataframes on 'Date'
    complete_data_df = pd.merge(filtered_patterns_df, cluster_data_df[['Date', 'Average Flow', 'k']], on='Date')

    # Save the combined data to a new CSV file
    complete_data_df.to_csv(paths['output'], index=False)
    print(f"Combined data saved to: {paths['output']} for {cluster_name} cluster")

def filter_and_update_csv(file_path, merged_data_dates):
    """
    Filters the given CSV file to only include dates present in the merged data and saves it back.

    Parameters:
    - file_path (str): Path to the CSV file to be updated.
    - merged_data_dates (set): Set of dates to filter by.

    Returns:
    - None
    """
    df = pd.read_csv(file_path)
    filtered_df = df[df['Date'].isin(merged_data_dates)]
    filtered_df.to_csv(file_path, index=False)
    print(f"Updated file saved: {file_path}")



def update_with_temperature(file_paths):  #does
    """
    Updates CSV files with temperature converted to Kelvin.

    Parameters:
    - file_paths (list): List of file paths to update.

    Returns:
    - None
    """
    for file_path in file_paths:
        df = pd.read_csv(file_path)
        df['Average Temperature (K)'] = (df['Average Temperature'] + 273.15).round(2)
        df.to_csv(file_path, index=False)
        print(f"Updated file saved with temperature in Kelvin: {file_path}")


import numpy as np
from math import exp, log

R = 8.314  # J/(mol*K)

def calculate_k_values(file_paths, A, Ea, R=8.314):
    """
    Calculates the k values using the Arrhenius equation and updates the CSV files.

    Parameters:
    - file_paths (list): List of file paths to update.
    - A (float): Pre-exponential factor for Arrhenius equation.
    - Ea (float): Activation energy for Arrhenius equation.
    - R (float): Universal gas constant, default is 8.314 J/(mol*K).

    Returns:
    - dict: Dictionary with the mean k values for each cluster.
    """
    mean_k_converted = {}

    for file_path in file_paths:
        df = pd.read_csv(file_path)
        df['k'] = (A * np.exp(-Ea / (R * df['Average Temperature (K)'])) * 86400).round(3)  # Convert k to 1/day
        df.to_csv(file_path, index=False)

        # Calculate and store the mean of 'k' for each file
        cluster_type = file_path.split('\\')[-1].split('_')[0]
        mean_k_converted[cluster_type] = df['k'].mean()

    return mean_k_converted



### *** Visualization functions for the demand pattern clustering *** 

def plot_flow_patterns(cluster_flow_patterns, output_path=None):   #works
    """
    Plots flow patterns for each cluster.

    Parameters:
    - cluster_flow_patterns (dict): Dictionary containing flow pattern data for each cluster.
    - output_path (str): Path to save the plot. If None, the plot is shown.

    Returns:
    - None
    """
    fig, axs = plt.subplots(2, 2, figsize=(14, 10))

    colors = ['red', 'blue', 'green', 'purple']
    titles = ['High Cluster Flow Patterns', 'Low Cluster Flow Patterns', 
              'Upper Medium Cluster Flow Patterns', 'Lower Medium Cluster Flow Patterns']

    for i, (cluster_name, df) in enumerate(cluster_flow_patterns.items()):
        row, col = divmod(i, 2)
        for j in range(len(df)):
            axs[row, col].plot(df.iloc[j], alpha=0.5, color=colors[i], linewidth=2, label=titles[i] if j == 0 else "")
        axs[row, col].set_title(titles[i])
        axs[row, col].set_xlabel('Hour')
        axs[row, col].set_ylabel('Flow Pattern')
        axs[row, col].grid(True)
        axs[row, col].legend()

    plt.tight_layout()
    
    if output_path:
        plt.savefig(output_path)
    else:
        plt.show()



    

