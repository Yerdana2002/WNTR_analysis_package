import main 
import flow_pattern
import pandas as pd
import os


# file_path = r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/data/All_Flow_Pattern_Dateweek.csv"

# data = pd.read_csv(file_path)

# scaled_data, orig_data, scaler = flow_pattern.preprocess_data(file_path, drop_columns=['Date', 'Day_of_week'])

# pca_applied_df, pca_model = flow_pattern.apply_pca(scaled_data, variance_threshold = 0.80)

# best_k = flow_pattern.determine_optimal_clusters(pca_applied_df, max_clusters=10)

# flow_pattern.plot_silhouette(pca_applied_df, best_k)

# centroids_df, cluster_labels = flow_pattern.kmeans_clustering(pca_applied_df, best_k, pca_model, scaler, orig_data)

# output_path=r"/Users/yerdanamaulenbay/Downloads/4gmm/pic/cluster_test"

# flow_pattern.plot_cluster_centroids(centroids_df, os.path.join(output_path, "demand_pattern_plot.png"))
# flow_pattern.save_centroids(centroids_df, os.path.join(output_path, "representative_demand_patterns.csv"))
# flow_pattern.save_clusters_to_csv(data, cluster_labels, os.path.join(output_path, "All_Flow_Pattern_Dateweek_cluster.csv"))

# merg = flow_pattern.merge_and_analyze(
#     r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/data/All_average_flows&Temperature_cluster.csv", 
#     r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/data/All_Flow_Pattern_Dateweek_cluster.csv", 
#     r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/data/merged_data.csv"
# )


# #Perform basic analysis and boxplot of 'Average Flow' by cluster pattern
# flow_pattern.analyze_cluster_patterns(merg, r"/Users/yerdanamaulenbay/Downloads/4gmm/pic/cluster_test", feature_column='Average Flow')

# flow_pattern.analyze_cluster_pattern_distribution(merg, output_base_dir=r"/Users/yerdanamaulenbay/Downloads/4gmm/pic/cluster_test")


# cluster_paths = {
#     'High': r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/data/High_cluster_data.csv",
#     'Upper-Medium': r"/Users/yerdanamaulenbay/Downloads/4gmm/data/Upper-Medium_cluster_data.csv", 
#     'Lower-Medium': r"/Users/yerdanamaulenbay/Downloads/4gmm/data/Lower_Medium_cluster_data.csv",
#     'Low': r"/Users/yerdanamaulenbay/Downloads/4gmm/data/Low_cluster_data.csv"
# }

# flow_pattern_path = r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/data/All_Flow_Pattern_Dateweek_cluster.csv"
# output_base_dir = r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/pic/finial_rep_patter"

# flow_pattern.filter_flow_patterns_and_save(cluster_paths, flow_pattern_path, output_base_dir)
# For high cluster
# expected_probabilities = {
#     3: 0.14,
#     2: 0.86
# }



# flow_pattern.compare_actual_to_expected_probabilities(merg, 'High', expected_probabilities)

# flow_pattern.merge_and_save_data('High', {
#     "filtered_patterns": r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/simulation/data/filtered_high_cluster_flow_patterns.csv",
#     "cluster_data": r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/data/High_cluster_data.csv",
#     "output": r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/simulation/data/high_complete_data.csv"
# })

# Define file paths
file_path = r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/data/All_Flow_Pattern_Dateweek.csv"
average_flows_path = r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/data/All_average_flows&Temperature_cluster.csv"
output_dir = r"/Users/yerdanamaulenbay/Downloads/4gmm/pic/cluster_test"
representative_patterns_path = r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/data/All_Flow_Pattern_Dateweek_cluster.csv"

# Cluster paths
cluster_paths = {
    'High': r"/Users/yerdanamaulenbay/Documents/WNTR_package_lib/4gmm/data/High_cluster_data.csv",
    'Upper-Medium': r"/Users/yerdanamaulenbay/Downloads/4gmm/data/Upper-Medium_cluster_data.csv",
    'Lower-Medium': r"/Users/yerdanamaulenbay/Downloads/4gmm/data/Lower_Medium_cluster_data.csv",
    'Low': r"/Users/yerdanamaulenbay/Downloads/4gmm/data/Low_cluster_data.csv"
}

# Expected probabilities
expected_probabilities = {
    3: 0.14,
    2: 0.86
}

# Call the full flow pattern analysis
flow_pattern.full_flow_pattern_analysis(
    file_path,
    average_flows_path=average_flows_path,
    output_dir=output_dir,
    cluster_paths=cluster_paths,
    variance_threshold=0.80,
    max_clusters=10,
    expected_probabilities=expected_probabilities,
    representative_patterns_path=representative_patterns_path
)



## Consider to name clusters A B C instead of 0 1 2 or 1 2 3 to avoid the confusion by pythonic indexing