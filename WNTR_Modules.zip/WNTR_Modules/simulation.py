import wntr
import numpy as np
import logging
from wntr_operations import apply_patterns, update_decay_coeff

def simulate_concentration(wn, node_name='90', attribute='quality'):
    try:
        sim = wntr.sim.EpanetSimulator(wn)
        results = sim.run_sim()

        concentration = results.node[attribute].loc[:, node_name] * 1000  # Convert to mg/L if 'quality'
            ## Make sure that the user specifies chlorine quality
    ## In EPANET the term quality may refer to chlorine or any other substance
        time_hours = np.array(results.node[attribute].index / 3600)  # Convert time to hours

        return concentration, time_hours
    except Exception as e:
        logging.error(f"Simulation failed: {e}")
        return None, None

def filter_concentration(concentration, time_hours, start_time=24, end_time=48, i=None, cluster_name='High'):
    mask = (time_hours >= start_time) & (time_hours < end_time)
    filtered_concentrations = concentration[mask]

    if len(filtered_concentrations) > 0:
        return filtered_concentrations.tolist()
    else:
        if i is not None:
            logging.info(f"No data for simulation {i+1} in {cluster_name} cluster")
        else:
            logging.info(f"No data in the specified time interval ({start_time}-{end_time} hours) in {cluster_name} cluster")
        return []
